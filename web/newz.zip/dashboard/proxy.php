<?php
/**
 * Chuck Norris AI - Dashboard API proxy (adds API key server-side so browser never sees it)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/auth_web.php';

header('Content-Type: application/json; charset=utf-8');

$path = $_GET['path'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$key = defined('DASHBOARD_API_KEY') ? DASHBOARD_API_KEY : '';

if (!$path || !$key) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing path or API key not configured']);
    exit;
}

$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$apiBase = str_replace('/dashboard', '/api', $base);
$url = $apiBase . '/' . ltrim($path, '/');
$fullUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $url;

$headers = [
    'X-API-Key: ' . $key,
    'Content-Type: application/json',
];
$body = $method === 'POST' ? file_get_contents('php://input') : null;

$ctx = stream_context_create([
    'http' => [
        'method' => $method,
        'header' => implode("\r\n", $headers),
        'content' => $body,
        'timeout' => 300,
    ],
]);

$response = @file_get_contents($fullUrl, false, $ctx);
if ($response === false) {
    http_response_code(502);
    echo json_encode(['error' => 'API request failed']);
    exit;
}

$code = 200;
if (isset($http_response_header[0]) && preg_match('/ (\d{3}) /', $http_response_header[0], $m)) {
    $code = (int)$m[1];
}
http_response_code($code);
echo $response;
