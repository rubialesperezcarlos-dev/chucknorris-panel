<?php
/**
 * Chuck Norris AI - Web Dashboard
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/auth_web.php';
// Calcular URLs - funciona tanto en raíz como en subdirectorio
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
$proxyUrl = $scriptDir . '/proxy.php';
$downloadToken = defined('DASHBOARD_API_KEY') ? hash('sha256', DASHBOARD_API_KEY) : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chuck Norris AI - Control Panel</title>
    <style>
        :root {
            --bg: #0d1117;
            --surface: #161b22;
            --border: #30363d;
            --text: #e6edf3;
            --accent: #58a6ff;
            --success: #3fb950;
            --warn: #d29922;
            --danger: #f85149;
        }
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 20px; }
        .container { max-width: 1400px; margin: 0 auto; }
        h1 { font-size: 1.75rem; margin-bottom: 24px; color: var(--accent); }
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 20px; margin-bottom: 20px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--border); }
        th { color: #8b949e; font-weight: 600; }
        button, .btn { background: var(--accent); color: #fff; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; font-size: 14px; }
        button:hover, .btn:hover { opacity: 0.9; }
        button:disabled { opacity: 0.5; cursor: not-allowed; }
        input[type="url"], input[type="text"] { width: 100%; max-width: 500px; padding: 10px 12px; border: 1px solid var(--border); border-radius: 6px; background: var(--bg); color: var(--text); }
        .status { display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; }
        .status.online { background: rgba(63,185,80,0.2); color: var(--success); }
        .status.offline { background: rgba(248,81,73,0.2); color: var(--danger); }
        .status.running { background: rgba(88,166,255,0.2); color: var(--accent); }
        .status.pending { background: rgba(210,153,34,0.2); color: var(--warn); }
        .status.completed { background: rgba(63,185,80,0.2); color: var(--success); }
        .status.failed { background: rgba(248,81,73,0.2); color: var(--danger); }
        #logStream { font-family: 'Consolas', monospace; font-size: 12px; background: #0d1117; border: 1px solid var(--border); border-radius: 6px; padding: 12px; height: 400px; overflow-y: auto; white-space: pre-wrap; word-break: break-all; }
        .log-line { margin: 2px 0; }
        .log-line.error { color: var(--danger); }
        .log-line.warn { color: var(--warn); }
        .hidden { display: none; }
        .flex { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
        a { color: var(--accent); text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Chuck Norris AI – Panel de control</h1>
        <p style="margin-top: -12px; margin-bottom: 20px;"><a href="logout.php">Cerrar sesión</a></p>

        <div class="card">
            <h2 style="margin-top:0;">Nuevo escaneo</h2>
            <div class="flex">
                <input type="url" id="targetUrl" placeholder="https://ejemplo.com" />
                <button id="btnCreate">Iniciar escaneo</button>
            </div>
            <p style="color:#8b949e; font-size: 13px; margin-top: 8px;">Se asignará al worker con más RAM disponible (32GB prioritario).</p>
        </div>

        <div class="card">
            <h2 style="margin-top:0;">Workers</h2>
            <div id="workersList">Cargando…</div>
        </div>

        <div class="card">
            <h2 style="margin-top:0;">Tareas</h2>
            <div id="tasksList">Cargando…</div>
        </div>

        <div class="card" id="logPanel" style="display:none;">
            <h2 style="margin-top:0;">Logs en vivo – Tarea <span id="logTaskId"></span></h2>
            <div id="logStream"></div>
            <p style="margin-bottom:0;"><button id="btnCloseLog">Cerrar</button></p>
        </div>

        <div class="card">
            <h2 style="margin-top:0;">Reportes</h2>
            <div id="reportsList">Cargando…</div>
        </div>
    </div>

    <script>
        const proxy = '<?= htmlspecialchars($proxyUrl) ?>';
        const downloadToken = '<?= htmlspecialchars($downloadToken) ?>';

        function api(path, options = {}) {
            const url = proxy + '?path=' + encodeURIComponent(path);
            return fetch(url, { method: options.method || 'GET', ...options }).then(r => r.json());
        }

        function post(path, body) {
            return api(path, { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } });
        }

        // Workers
        function loadWorkers() {
            api('workers/list').then(data => {
                const list = document.getElementById('workersList');
                if (!data.workers || data.workers.length === 0) {
                    list.innerHTML = '<p>No hay workers registrados.</p>';
                    return;
                }
                list.innerHTML = '<table><thead><tr><th>Host</th><th>RAM</th><th>CPU</th><th>Tareas</th><th>Estado</th><th>Último heartbeat</th></tr></thead><tbody>' +
                    data.workers.map(w => '<tr><td>' + escapeHtml(w.hostname) + '</td><td>' + (w.ram_used_mb || 0) + ' / ' + (w.ram_total_mb || 0) + ' MB</td><td>' + (w.cpu_usage_percent || 0) + '%</td><td>' + (w.active_tasks || 0) + '</td><td><span class="status ' + (w.status || 'offline') + '">' + (w.status || 'offline') + '</span></td><td>' + (w.last_heartbeat_at || '-') + '</td></tr>').join('') +
                    '</tbody></table>';
            }).catch(() => { document.getElementById('workersList').innerHTML = '<p>Error al cargar workers.</p>'; });
        }

        // Tasks
        function loadTasks() {
            api('tasks/list').then(data => {
                const list = document.getElementById('tasksList');
                if (!data.tasks || data.tasks.length === 0) {
                    list.innerHTML = '<p>No hay tareas.</p>';
                    return;
                }
                list.innerHTML = '<table><thead><tr><th>ID</th><th>URL</th><th>Estado</th><th>Worker</th><th>Creado</th><th>Acciones</th></tr></thead><tbody>' +
                    data.tasks.map(t => '<tr><td>' + t.id + '</td><td>' + escapeHtml(t.target_url) + '</td><td><span class="status ' + (t.status || '') + '">' + (t.status || '') + '</span></td><td>' + escapeHtml(t.worker_hostname || '-') + '</td><td>' + (t.created_at || '') + '</td><td><button class="btn btn-log" data-id="' + t.id + '">Ver logs</button> ' + ((t.status === 'completed' || t.status === 'failed') ? '<a href="generate_report.php?task_id=' + t.id + '&token=' + downloadToken + '" class="btn" target="_blank">Reporte HTML</a>' : '') + '</td></tr>').join('') +
                    '</tbody></table>';
                document.querySelectorAll('.btn-log').forEach(el => el.addEventListener('click', () => openLog(el.dataset.id)));
            }).catch(() => { document.getElementById('tasksList').innerHTML = '<p>Error al cargar tareas.</p>'; });
        }

        function escapeHtml(s) {
            if (!s) return '';
            const d = document.createElement('div');
            d.textContent = s;
            return d.innerHTML;
        }

        // Create task
        document.getElementById('btnCreate').addEventListener('click', () => {
            const url = document.getElementById('targetUrl').value.trim();
            if (!url) return alert('Introduce una URL.');
            document.getElementById('btnCreate').disabled = true;
            post('tasks/create', { target_url: url }).then(data => {
                if (data.error) alert(data.error);
                else { document.getElementById('targetUrl').value = ''; loadTasks(); }
            }).finally(() => { document.getElementById('btnCreate').disabled = false; });
        });

        // Reports list: by task
        function loadReports() {
            api('reports/list').then(data => {
                const list = document.getElementById('reportsList');
                if (!data.reports || data.reports.length === 0) {
                    list.innerHTML = '<p>No hay reportes.</p>';
                    return;
                }
                list.innerHTML = '<table><thead><tr><th>ID</th><th>Task ID</th><th>Archivo</th><th>Fecha</th><th></th></tr></thead><tbody>' +
                    data.reports.map(r => '<tr><td>' + r.id + '</td><td>' + r.task_id + '</td><td>' + escapeHtml(r.filename) + '</td><td>' + (r.created_at || '') + '</td><td><a href="download_report.php?id=' + r.id + '&token=' + downloadToken + '">Descargar</a></td></tr>').join('') +
                    '</tbody></table>';
            }).catch(() => { document.getElementById('reportsList').innerHTML = '<p>Error al cargar reportes.</p>'; });
        }

        // Live logs
        let logTaskId = null;
        let logPollTimer = null;
        let lastLogId = 0;

        function openLog(taskId) {
            logTaskId = parseInt(taskId, 10);
            document.getElementById('logPanel').style.display = 'block';
            document.getElementById('logTaskId').textContent = logTaskId;
            document.getElementById('logStream').innerHTML = '';
            lastLogId = 0;
            pollLogs();
        }

        function pollLogs() {
            if (!logTaskId) return;
            const path = 'tasks/logs/get?task_id=' + logTaskId + '&after_id=' + lastLogId + '&limit=100';
            api(path).then(data => {
                if (!data.logs || !data.logs.length) { schedulePoll(); return; }
                const stream = document.getElementById('logStream');
                data.logs.forEach(l => {
                    lastLogId = Math.max(lastLogId, l.id);
                    const div = document.createElement('div');
                    div.className = 'log-line ' + (l.level || '');
                    div.textContent = '[' + (l.created_at || '') + '] ' + (l.log_line || '');
                    stream.appendChild(div);
                });
                stream.scrollTop = stream.scrollHeight;
                schedulePoll();
            }).catch(() => schedulePoll());
        }

        function schedulePoll() {
            if (logPollTimer) clearTimeout(logPollTimer);
            if (!logTaskId) return;
            logPollTimer = setTimeout(pollLogs, 1500);
        }

        document.getElementById('btnCloseLog').addEventListener('click', () => {
            if (logPollTimer) clearTimeout(logPollTimer);
            logTaskId = null;
            logPollTimer = null;
            document.getElementById('logPanel').style.display = 'none';
        });

        // Refresh lists
        loadWorkers();
        loadTasks();
        loadReports();
        setInterval(loadWorkers, 10000);
        setInterval(loadTasks, 8000);
        setInterval(loadReports, 15000);
    </script>
</body>
</html>
