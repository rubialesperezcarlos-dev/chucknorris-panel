<?php
/**
 * Chuck Norris AI - Tasks API
 * Create, list, poll (assign), get task; append logs; upload results/reports
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/auth.php';

const DEFAULT_INSTRUCTION = 'Act as a professional penetration tester. This is NOT a CTF and there are NO flags. Your objective is to discover real vulnerabilities in the target web application. Focus on OWASP Top 10 issues, authentication bypass, IDOR, XSS, SQL injection, SSRF, file upload vulnerabilities, and security misconfigurations. Provide step-by-step methodology and suggested tools.';

function validateTargetUrl(string $url): bool {
    $parsed = parse_url($url);
    if (!$parsed || empty($parsed['host'])) {
        return false;
    }
    return in_array(strtolower($parsed['scheme'] ?? ''), ['http', 'https'], true);
}

function api_tasks_create(): void {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $target_url = trim($input['target_url'] ?? '');
    $instruction = trim($input['instruction'] ?? DEFAULT_INSTRUCTION) ?: DEFAULT_INSTRUCTION;

    if (!$target_url || !validateTargetUrl($target_url)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid or missing target_url (must be http(s) URL)']);
        return;
    }

    $pdo = getDb();
    $stmt = $pdo->prepare('INSERT INTO tasks (target_url, instruction, status) VALUES (?, ?, "pending")');
    $stmt->execute([$target_url, $instruction]);
    $id = (int)$pdo->lastInsertId();
    echo json_encode(['task_id' => $id, 'target_url' => $target_url, 'status' => 'pending']);
}

function api_tasks_list(): void {
    requireAuth();
    $status = $_GET['status'] ?? null;
    $pdo = getDb();
    $sql = 'SELECT t.id, t.target_url, t.status, t.worker_id, t.assigned_at, t.started_at, t.completed_at, t.created_at, t.error_message, w.hostname AS worker_hostname FROM tasks t LEFT JOIN workers w ON t.worker_id = w.id WHERE 1=1';
    $params = [];
    if ($status !== null && $status !== '') {
        $sql .= ' AND t.status = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY t.id DESC LIMIT 500';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['tasks' => $stmt->fetchAll()]);
}

/**
 * Scheduler: assign pending task to best worker (highest ram, lowest load)
 */
function pickBestWorker(PDO $pdo): ?array {
    $stmt = $pdo->query('SELECT id, ram_total_mb, ram_used_mb, cpu_usage_percent, active_tasks FROM workers WHERE status = "online" ORDER BY ram_total_mb DESC, active_tasks ASC, cpu_usage_percent ASC LIMIT 10');
    $workers = $stmt->fetchAll();
    return $workers[0] ?? null;
}

function api_tasks_poll(): void {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $worker_id = (int)($input['worker_id'] ?? 0);
    if ($worker_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'worker_id required']);
        return;
    }

    $pdo = getDb();
    $worker = $pdo->prepare('SELECT id FROM workers WHERE id = ?');
    $worker->execute([$worker_id]);
    if (!$worker->fetch()) {
        http_response_code(404);
        echo json_encode(['error' => 'Worker not found']);
        return;
    }

    $best = pickBestWorker($pdo);
    if (!$best || (int)$best['id'] !== $worker_id) {
        echo json_encode(['task' => null]);
        return;
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT id, target_url, instruction FROM tasks WHERE status = "pending" ORDER BY id ASC LIMIT 1 FOR UPDATE');
        $stmt->execute();
        $task = $stmt->fetch();
        if (!$task) {
            $pdo->commit();
            echo json_encode(['task' => null]);
            return;
        }
        $task_id = (int)$task['id'];
        $pdo->prepare('UPDATE tasks SET status = "assigned", worker_id = ?, assigned_at = NOW() WHERE id = ?')->execute([$worker_id, $task_id]);
        $pdo->prepare('UPDATE workers SET active_tasks = active_tasks + 1 WHERE id = ?')->execute([$worker_id]);
        $pdo->commit();
        echo json_encode(['task' => ['id' => $task_id, 'target_url' => $task['target_url'], 'instruction' => $task['instruction']]]);
    } catch (Throwable $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['error' => 'Assignment failed']);
    }
}

function api_tasks_get(): void {
    requireAuth();
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid task id']);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT t.*, w.hostname AS worker_hostname FROM tasks t LEFT JOIN workers w ON t.worker_id = w.id WHERE t.id = ?');
    $stmt->execute([$id]);
    $task = $stmt->fetch();
    if (!$task) {
        http_response_code(404);
        echo json_encode(['error' => 'Task not found']);
        return;
    }
    echo json_encode($task);
}

function api_tasks_start(): void {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $task_id = (int)($input['task_id'] ?? 0);
    $worker_id = (int)($input['worker_id'] ?? 0);
    if ($task_id <= 0 || $worker_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'task_id and worker_id required']);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('UPDATE tasks SET status = "running", started_at = NOW() WHERE id = ? AND worker_id = ? AND status = "assigned"');
    $stmt->execute([$task_id, $worker_id]);
    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Task not found or not assigned to this worker']);
        return;
    }
    echo json_encode(['ok' => true]);
}

function api_tasks_complete(): void {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $task_id = (int)($input['task_id'] ?? 0);
    $worker_id = (int)($input['worker_id'] ?? 0);
    $error_message = $input['error_message'] ?? null;
    if ($task_id <= 0 || $worker_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'task_id and worker_id required']);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('UPDATE tasks SET status = ?, completed_at = NOW(), error_message = ? WHERE id = ? AND worker_id = ?');
    $stmt->execute([$error_message ? 'failed' : 'completed', $error_message, $task_id, $worker_id]);
    if ($stmt->rowCount() > 0) {
        $pdo->prepare('UPDATE workers SET active_tasks = GREATEST(0, active_tasks - 1) WHERE id = ?')->execute([$worker_id]);
    }
    echo json_encode(['ok' => true]);
}

function api_tasks_logs_append(): void {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $task_id = (int)($input['task_id'] ?? 0);
    $worker_id = (int)($input['worker_id'] ?? 0);
    $lines = $input['lines'] ?? [];
    $level = $input['level'] ?? 'stdout';
    if ($task_id <= 0 || $worker_id <= 0 || !is_array($lines)) {
        http_response_code(400);
        echo json_encode(['error' => 'task_id, worker_id and lines (array) required']);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT id FROM tasks WHERE id = ? AND worker_id = ?');
    $stmt->execute([$task_id, $worker_id]);
    if (!$stmt->fetch()) {
        http_response_code(403);
        echo json_encode(['error' => 'Task not assigned to this worker']);
        return;
    }
    $insert = $pdo->prepare('INSERT INTO task_logs (task_id, log_line, level) VALUES (?, ?, ?)');
    foreach (array_slice($lines, 0, 200) as $line) {
        $insert->execute([$task_id, (string)$line, $level]);
    }
    echo json_encode(['ok' => true, 'count' => count($lines)]);
}

function api_tasks_logs_get(): void {
    requireAuth();
    $task_id = (int)($_GET['task_id'] ?? 0);
    $after_id = (int)($_GET['after_id'] ?? 0);
    $limit = min(500, max(1, (int)($_GET['limit'] ?? 100)));
    if ($task_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'task_id required']);
        return;
    }
    $pdo = getDb();
    if ($after_id > 0) {
        $stmt = $pdo->prepare('SELECT id, task_id, log_line, level, created_at FROM task_logs WHERE task_id = ? AND id > ? ORDER BY id ASC LIMIT ?');
        $stmt->execute([$task_id, $after_id, $limit]);
    } else {
        $stmt = $pdo->prepare('SELECT id, task_id, log_line, level, created_at FROM task_logs WHERE task_id = ? ORDER BY id ASC LIMIT ?');
        $stmt->execute([$task_id, $limit]);
    }
    echo json_encode(['logs' => $stmt->fetchAll()]);
}

function api_tasks_results_upload(): void {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $task_id = (int)($input['task_id'] ?? 0);
    $worker_id = (int)($input['worker_id'] ?? 0);
    $raw_output = $input['raw_output'] ?? null;
    $findings_json = isset($input['findings_json']) ? (is_string($input['findings_json']) ? $input['findings_json'] : json_encode($input['findings_json'])) : null;
    $summary = $input['summary'] ?? null;
    if ($task_id <= 0 || $worker_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'task_id and worker_id required']);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT id FROM tasks WHERE id = ? AND worker_id = ?');
    $stmt->execute([$task_id, $worker_id]);
    if (!$stmt->fetch()) {
        http_response_code(403);
        echo json_encode(['error' => 'Task not assigned to this worker']);
        return;
    }
    $stmt = $pdo->prepare('INSERT INTO scan_results (task_id, raw_output, findings_json, summary) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE raw_output=VALUES(raw_output), findings_json=VALUES(findings_json), summary=VALUES(summary)');
    $stmt->execute([$task_id, $raw_output, $findings_json, $summary]);
    echo json_encode(['ok' => true]);
}

function api_reports_upload(): void {
    requireAuth();
    $task_id = (int)($_POST['task_id'] ?? 0);
    $worker_id = (int)($_POST['worker_id'] ?? 0);
    if ($task_id <= 0 || $worker_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'task_id and worker_id required']);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT id FROM tasks WHERE id = ? AND worker_id = ?');
    $stmt->execute([$task_id, $worker_id]);
    if (!$stmt->fetch()) {
        http_response_code(403);
        echo json_encode(['error' => 'Task not assigned to this worker']);
        return;
    }
    if (empty($_FILES['report']['tmp_name']) || !is_uploaded_file($_FILES['report']['tmp_name'])) {
        http_response_code(400);
        echo json_encode(['error' => 'No file uploaded']);
        return;
    }
    $ext = pathinfo($_FILES['report']['name'], PATHINFO_EXTENSION) ?: 'txt';
    $filename = 'report_task' . $task_id . '_' . date('Y-m-d_His') . '.' . $ext;
    $dir = REPORTS_DIR;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $path = $dir . '/' . $filename;
    if (!move_uploaded_file($_FILES['report']['tmp_name'], $path)) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save file']);
        return;
    }
    $mime = $_FILES['report']['type'] ?? 'application/octet-stream';
    $size = (int)filesize($path);
    $stmt = $pdo->prepare('INSERT INTO reports (task_id, filename, file_path, mime_type, file_size) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$task_id, $filename, $path, $mime, $size]);
    echo json_encode(['ok' => true, 'report_id' => (int)$pdo->lastInsertId(), 'filename' => $filename]);
}

function api_reports_list(): void {
    requireAuth();
    $task_id = (int)($_GET['task_id'] ?? 0);
    $pdo = getDb();
    $sql = 'SELECT id, task_id, filename, file_path, mime_type, file_size, created_at FROM reports';
    $params = [];
    if ($task_id > 0) {
        $sql .= ' WHERE task_id = ?';
        $params[] = $task_id;
    }
    $sql .= ' ORDER BY id DESC LIMIT 100';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['reports' => $stmt->fetchAll()]);
}

function api_reports_download(): void {
    requireAuth();
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        return;
    }
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT filename, file_path, mime_type FROM reports WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row || !file_exists($row['file_path'])) {
        http_response_code(404);
        return;
    }
    header('Content-Type: ' . $row['mime_type']);
    header('Content-Disposition: attachment; filename="' . basename($row['filename']) . '"');
    header('Content-Length: ' . filesize($row['file_path']));
    readfile($row['file_path']);
    exit;
}
